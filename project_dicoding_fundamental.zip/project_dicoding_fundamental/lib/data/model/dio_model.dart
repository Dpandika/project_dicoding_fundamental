import 'package:equatable/equatable.dart';

//MODEL CLASS
class DioModel extends Equatable {
  final String? id;
  final String? name;
  final String? description;
  final String? city;
  final String? address;
  final String? pictureId;
  final double? rating;
  final List<DioCategory>? categories;
  final DioMenus? menus;
  final List<DioCustomerReviews>? customerReviews;

  const DioModel({
    this.id,
    this.name,
    this.description,
    this.city,
    this.address,
    this.pictureId,
    this.rating,
    this.categories,
    this.menus,
    this.customerReviews,
  });

  factory DioModel.fromJson(Map<String, dynamic> json) =>
      DioModel(
        id: json['id'] as String?,
        name: json['name'] as String?,
        description: json['description'] as String?,
        city: json['city'] as String?,
        address: json['address'] as String?,
        pictureId: json['pictureId'] as String?,
        rating: (json['rating'] as num?)?.toDouble(),
        categories: (json['categories'] as List<dynamic>?)
            ?.map((e) => DioCategory.fromJson(e as Map<String, dynamic>))
            .toList(),
        menus: json['menus'] == null
            ? null
            : DioMenus.fromJson(json['menus'] as Map<String, dynamic>),
        customerReviews: (json['customerReviews'] as List<dynamic>?)
            ?.map((e) => DioCustomerReviews.fromJson(e as Map<String, dynamic>))
            .toList(),
      );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'city': city,
    'pictureId': pictureId,
    'rating': rating,
  };

  @override
  List<Object?> get props => [
    id,
    name,
    description,
    city,
    address,
    pictureId,
    rating,
    categories,
    menus,
    customerReviews,
  ];
}

//FOOD AND DRINK CLASS
class DioFoodAndDrink extends Equatable {
  final String? name;

  const DioFoodAndDrink({this.name});

  factory DioFoodAndDrink.fromJson(Map<String, dynamic> json) => DioFoodAndDrink(
    name: json['name'] as String?,
  );

  Map<String, dynamic> toJson() => {
    'name': name,
  };

  @override
  List<Object?> get props => [name];
}

//MENUS CLASS
class DioMenus extends Equatable {
  final List<DioFoodAndDrink>? foods;
  final List<DioFoodAndDrink>? drinks;

  const DioMenus({this.foods, this.drinks});

  factory DioMenus.fromJson(Map<String, dynamic> json) => DioMenus(
    foods: (json['foods'] as List<dynamic>?)
        ?.map((e) => DioFoodAndDrink.fromJson(e as Map<String, dynamic>))
        .toList(),
    drinks: (json['drinks'] as List<dynamic>?)
        ?.map((e) => DioFoodAndDrink.fromJson(e as Map<String, dynamic>))
        .toList(),
  );

  Map<String, dynamic> toJson() => {
    'foods': foods?.map((e) => e.toJson()).toList(),
    'drinks': drinks?.map((e) => e.toJson()).toList(),
  };

  @override
  List<Object?> get props => [foods, drinks];
}

//CUSTOMER REVIEW CLASS
class DioCustomerReviews extends Equatable {
  final String? name;
  final String? review;
  final String? date;

  const DioCustomerReviews({this.name, this.review, this.date});

  factory DioCustomerReviews.fromJson(Map<String, dynamic> json) {
    return DioCustomerReviews(
      name: json['name'] as String?,
      review: json['review'] as String?,
      date: json['date'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
    'name': name,
    'review': review,
    'date': date,
  };

  @override
  List<Object?> get props => [name, review, date];
}

//CATEGORY CLASS
class DioCategory extends Equatable {
  final String? name;

  const DioCategory({this.name});

  factory DioCategory.fromJson(Map<String, dynamic> json) => DioCategory(
    name: json['name'],
  );

  Map<String, dynamic> toJson() => {
    'name': name,
  };

  @override
  List<Object?> get props => [name];
}

//RESPONSE CLASS
class DioToResponse extends Equatable {
  final List<DioModel> restaurant;

  const DioToResponse({required this.restaurant});

  factory DioToResponse.fromJson(Map<String, dynamic> json) =>
      DioToResponse(
        restaurant: List<DioModel>.from((json["restaurants"] as List)
            .map((x) => DioModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
    "restaurants": List<dynamic>.from(restaurant.map((x) => x.toJson())),
  };

  @override
  List<Object?> get props => [restaurant];
}